// Yet another well-adjusted printing program
#include <iostream>
using namespace std;

int main()
{
   cout << "The following items were top sellers\n";
   cout << "during the month of June:\n";
   cout << "Computer games\nCoffee";
   cout << "\nAspirin\n";
   return 0;
} 